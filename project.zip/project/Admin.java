public class Admin extends Person {
private int employeeid;
    public Admin(String name, String Address, int phone) {
        super(name, Address, phone);
        this.employeeid=employeeid
        
    }

    
    public int getemployeeid() {
        return employeeid;
    }

    public void setemployeeid(int employeeid) {
        this.employeeid= employeeid;
    }


    
}
