public class Customer extends Person(
    private int custid;

    public Customer
)