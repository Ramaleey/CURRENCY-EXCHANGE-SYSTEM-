public class Main{
     exchange me = new exchange(200,300);
     Person we = new Person("juma","bububu",0778456271);
     Customer pe = new Costomer("jumaa","bububuu",0778456273,12);
     Mein te = new Mein ();
    Admin re = new Admin("jumaa","bububuu",0778456273);



}