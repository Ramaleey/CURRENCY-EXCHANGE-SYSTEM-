import java.util.Scanner;
public class Mein extends exchange{
    public Mein(){

    }
public static void main(String[]args){
    int back;
    
    do{
        System.out.println("\t\t\tWELL COME TO RAMAEXCHANGE RATE\n1.dollar -TZSH\n2.TZSH-dollar\n3.dollar-pound\n4.pound-dollar\n5.dollar-euro\n 6.euro-dollar");
    Mein obj =new Mein();
        Scanner input =new Scanner(System.in);
        int choice = input.nextInt();
        switch(choice){
            case 1:obj.dolltsh();
            obj.msg();
            break;
            case 2:obj.tshdoll();
            obj.msg();
            break;
            case 3:obj.dollpound();
            obj.msg();
            break;
            case 4:obj.pounddoll();
            obj.msg();
            break;
            case 5:obj.dolleuro();
            obj.msg();
            break;
            case 6:obj.uerodoll();
            obj.msg();
            break;
        }
        System.out.println("menu: 1");
        back =input.nextInt();
    }while(back ==1);
 
    
}
    
}
