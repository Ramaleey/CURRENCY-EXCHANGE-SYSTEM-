public class Person {
    private String name;
    private String address;
    private int phone;
    public Person(String name,String Address,int phone){
        this.name=name;
        this.address=Address;
        this.phone=phone;
    }

    public void setname(String name){
        this.name=name;
    }
    public String getname(){
        return name;
    }
    public void setaddress(String address){
        this.address=address;
    }
    public String getaddress(){
        return address;
    }
    public void setphone(String phone){
        this.phone=phone;
    }
    public String getphone(){
        return phone;
    }
    


    
}
