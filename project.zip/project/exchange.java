import java.util.Scanner;
public class exchange{
    private double rate;
    private double money;
    public exchange(){

    }
     public  exchange(double r){
        rate =r;
     }public void tshdoll(){
        System.out.println("enter the amount");
        Scanner input =new Scanner(System.in);
        double amount =input.nextDouble();
        money =amount/2300;
        System.out.println("your money is "+money+"$");

     }
     public void dolltsh(){
        System.out.println("enter the amount");
        Scanner put =new Scanner(System.in);
        double amount =put.nextDouble();
        money =amount*2300;
        System.out.println("your money is "+money+"tsh");

     }
     public void dollpound(){
        System.out.println("enter the amount");
        Scanner iput =new Scanner(System.in);
        double amount =iput.nextDouble();
        money =amount*0.81;
        System.out.println("your money is "+money+"pound");

     }
     public void pounddoll(){
        System.out.println("enter the amount");
        Scanner enter =new Scanner(System.in);
        double amount =enter.nextDouble();
        money =amount/0.81;
        System.out.println("your money is "+money+"$");

     }public void dolleuro(){
        System.out.println("enter the amount");
        Scanner sn =new Scanner(System.in);
        double amount =sn.nextDouble();
        money =amount*0.91;
        System.out.println("your money is "+money+"euro");

     }
     public void uerodoll(){
        System.out.println("enter the amount");
        Scanner ns =new Scanner(System.in);
        double amount =ns.nextDouble();
        money =amount/0.91;
        System.out.println("your money is "+money+"$");

     }
     public void msg(){
        System.out.println("\tTHANKS FOR USING OUR SERVICE");
     }
     
     
}